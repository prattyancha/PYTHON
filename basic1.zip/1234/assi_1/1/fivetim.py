import five

def main():
	a=input("enter string:")
	print(five.FiveTime(a))
	
if __name__ == "__main__":
	main()
