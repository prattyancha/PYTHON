import rg

def main():
	value=int(input("enter no:"))
	
	if value>0:
		print(rg.reverse(value))
	else:
		return 0;
		
if __name__ == "__main__":
	main()
