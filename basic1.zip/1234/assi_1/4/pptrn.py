def Pattern(no):
	for i in range(no):
		print("*",end="")
