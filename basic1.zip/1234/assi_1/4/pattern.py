import pptrn

def main():
	value=int(input("Enter no:"))
	 
	print(pptrn.Pattern(value))
	
if __name__ == "__main__":
	main()
