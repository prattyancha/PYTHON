def DivisibleByFiv(no):
	if no>0:
		result=no%5
		return result
	
	if result==0:
		return True
	else:
		return False
