import div

def main():
	value=int(input("Enter no::"))
	
	ret=div.DivisibleByFiv(value)
	
	if ret==0:
		print("divisible")
	else:
		print("not divisible")
		
if __name__ == "__main__":
	main()
