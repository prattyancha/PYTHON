import check

def main():
	char=input("Enter alpha:")
	return check.Vowel(char)
	
if __name__ == "__main__":
	main()
