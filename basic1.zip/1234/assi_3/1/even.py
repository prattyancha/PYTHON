import eve

def main():
	value=int(input("Enter No:"))
	return eve.even(value)
	
if __name__ == "__main__":
	main()
