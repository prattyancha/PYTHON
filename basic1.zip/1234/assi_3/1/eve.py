
def even(no):
	for i in range(1,no):
		if i%2==0:
			print(i) 
