#Print Even Factors

def fact(no):
	if no<0:
		no=-no
		
	for i in range(1,no):
		ans=no/i
		if ans%2==0:
			print(ans,end=" || ")
