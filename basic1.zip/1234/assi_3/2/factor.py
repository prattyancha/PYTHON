import even

def main():
	value=int(input("Enter no:"))
	return even.fact(value)
	
if __name__ == "__main__":
	main()
