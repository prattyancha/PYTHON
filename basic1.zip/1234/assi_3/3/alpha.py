#Convert case
def conver(char):
	ch=ord(char)
	if ch>=97 and ch<=122:
		print(chr(ch-32))
	elif ch>=65 and ch<=90:
		print(chr(ch+32))
