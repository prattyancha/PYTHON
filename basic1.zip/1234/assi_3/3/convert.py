import alpha

def main():
	ch=input("enter character:")
	return alpha.conver(ch)
	
if __name__ == "__main__":
	main()
	
