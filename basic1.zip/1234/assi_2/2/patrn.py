def Pattern(no):
	if no==10:
		print("Hello")
	else:
		print("Demo")
