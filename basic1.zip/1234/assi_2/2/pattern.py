import patrn

def main():
	value=int(input("Enter no:"))
	return patrn.Pattern(value)

if __name__ == "__main__":
	main()
