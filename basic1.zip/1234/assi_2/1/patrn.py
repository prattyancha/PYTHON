def Pattern(no):
	i=0
	while i<no:
		print("*",end=" ")
		i=i+1
		
	
