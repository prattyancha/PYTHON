def Pattern(no1,no2):
	for i in range(no2):
		print(no1,end=" ")
	print()
