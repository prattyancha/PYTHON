import ptrn

def main():
	value1=int(input("Enter value1:"))
	value2=int(input("Enter value2:"))
	
	return ptrn.Pattern(value1,value2)
	
if __name__ == "__main__":
	main()
