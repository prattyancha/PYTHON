import fact

def main():
	value=int(input("enter no::"))
	return fact.Non_Fact(value)
	
if __name__ == "__main__":
	main()
