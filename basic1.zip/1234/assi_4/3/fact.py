#print all non-factors 

def Non_Fact(no):
	if no<0:
		no=-no
	print("Non-Factors:")
	for i in range(1,no):
		if no%i!=0:
			print(i,end=" ")
	print()
