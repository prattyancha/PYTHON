import Ssum

def main():
	value=int(input("Enter No:"))
	return Ssum.Non_Fact(value)
if __name__ == "__main__":
	main()
