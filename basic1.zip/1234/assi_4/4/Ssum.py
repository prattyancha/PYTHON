#print Sum of all non-factors 

def Non_Fact(no):
	ans=0
	if no<0:
		no=-no
		
	print("Non-Factors:")
	for i in range(1,no):
		if no%i!=0:
			ans=ans+i
	print("Sum is:",ans)
