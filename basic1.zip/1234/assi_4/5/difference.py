import facnfac

def main():
	value=int(input("Enter No:"))
	return facnfac.Fact(value)
	
if __name__ == "__main__":
	main()
