#Accept number from user and return multiplication of its factors


def FacMul(no):
	fact,ans,Ans=0,0,1
	if no<0:
		no=-no
	for fact in range(1,no-1):
		if no%fact==0:
			Ans=Ans*fact
			fact=fact+1
	print("multiplication is:",Ans)
