import mul

def main():
	value=int(input("Enter No:"))
	return mul.FacMul(value)
if __name__ == "__main__":
	main()
