#print factors in decreasing order

def fact(no):
	for i in range(1,no-1):
		if no%i==0:
			fact=no/i
			if fact!=no:
				print(fact,end=" | ")
