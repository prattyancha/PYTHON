import factors

def main():
	value=int(input("Enter no::"))
	return factors.fact(value)
	
if __name__ == "__main__":
	main()
